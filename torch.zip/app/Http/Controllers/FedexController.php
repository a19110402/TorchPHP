<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cookie;


class FedexController extends Controller
{
    public function index(){
        //$response = $this->postToken()['expires_in'];
        //return view('fedex.index', compact('response'));
        return view('fedex.index');
    }

    public function auth(){
        return view('fedex.auth');
    }

    public function findLocationForm()
    {   
        $countryCodes = $this->getCountryCode(); 
        return view('fedex.findLocationForm', compact('countryCodes'));
    }

    public function globalTradeForm(){
        $countryCodes = $this->getCountryCode(); 
        return view('fedex.globalTrade', compact('countryCodes'));
    }

    public function GroundDayCloseForm()
    {
        return view('fedex.groundDayClose');
    }

    public function reprintDayCloseRequest(Request $request)
    {
        $requestJson = json_decode($request->get('reprint_day_close'));
        $body = [
            "closeReqType"=> "GCDR",//$requestJson->{'closeReqType'}, //=> "GCDR",
            "reprintOption"=> "BY_SHIP_DATE",//$requestJson->{'closeReqType'}, //=> "GCDR",
            "groundServiceCategory"=> "GROUND",//$requestJson->{'groundServiceCategory'}, //=> "GROUND",
            "accountNumber" => [
                "value"=> "510051408"//$requestJson->{'accountNumber'},//=>"510051408",
            ],
            //"closeDate" => "2022-04-16",//$requestJson->{'closeDate'},//=> "2022-04-16",
        ];
        $response = $this->makeFedexJsonPostRequest(
            env('GROUND_DAY_CLOSE_TEST_URL'),
            env('GROUND_DAY_CLOSE_PRODUCTION_URL'),
            $body
        ); 
        return response()->json([
            'validateAddressJson' => $response->json(),
            'statusCode' => $response->status(),
            'cookie' => $body,
        ]);
    }

    public function GroundDayCloseRequest(Request $request){
        $requestJson = json_decode($request->get('ground_day_close'));
        $body = [
            "accountNumber" => [
                "value"=>$requestJson->{'accountNumber'},//=>"510051408",
            ],
            "closeReqType"=> $requestJson->{'closeReqType'}, //=> "GCDR",
            "closeDate" => $requestJson->{'closeDate'},//=> "2022-04-16",
            "groundServiceCategory"=> $requestJson->{'groundServiceCategory'}, //=> "GROUND",
        ];
        $response = $this->makeFedexJsonPutRequest(
            env('GROUND_DAY_CLOSE_TEST_URL'),
            env('GROUND_DAY_CLOSE_PRODUCTION_URL'),
            $body
        ); 
        return response()->json([
            'validateAddressJson' => $response->json(),
            'statusCode' => $response->status(),
            'cookie' => $body,
        ]);
    }

    public function postToken(Request $request){
        $response = HTTP::asForm()->post(env('PRODUCTION_ENV') ?
        env('AUTHORIZATION_API_PRODUCITON_URL'): env('AUTHORIZATION_API_TEST_URL'), [
            'grant_type' => 'client_credentials',
            'client_id' => env('PRODUCTION_ENV') ?
            env('CLIENT_ID_FEDEX_PRODUCTION'): env('CLIENT_ID_FEDEX_TEST'),
            'client_secret' => env('PRODUCTION_ENV') ?
            env('CLIENT_SECRET_FEDEX_PRODUCTION'): env('CLIENT_SECRET_FEDEX_TEST'),
            'child_Key' => $request->get('client_id'),
            'child_secret' => $request->get('child_secret'),
        ]);
        $responseJson = $response;
        $responseJson->json();
        Cookie::queue(Cookie::forget('access_token_fedex'));
        Cookie::queue(Cookie::forget('token_type'));
        Cookie::queue(Cookie::forget('scope'));
        Cookie::queue(Cookie::make('access_token_fedex', $responseJson['access_token'], $responseJson['expires_in']));
        Cookie::queue(Cookie::make('token_type', $responseJson['token_type'], $responseJson['expires_in']));
        Cookie::queue(Cookie::make('scope', $responseJson['scope'], $responseJson['expires_in']));
        return response()->json([
            'answer' => $responseJson['token_type']." ".$responseJson['access_token'],
            'statusCode' => $response->status(),
            'cookie' => Cookie::get('token_type')." ".Cookie::get('access_token_fedex'),
        ]);
    }

    public function findLocationRequest(Request $request)
    {
        $locationJson = json_decode($request->get('find_location'));
        $body = [
            "location" => [
                "address"=>[
                    "countryCode"=>$locationJson->{'country_code'},
                    "city"=>$locationJson->{'city'},
                ],
                "longLat"=>[
                    "latitude"=>$locationJson->{'latitude'},
                    "longitude"=>$locationJson->{'longitude'},
                ],
            ]
        ];
        $response = $this->makeFedexJsonPostRequest(
            env('FIND_LOCATION_API_TEST_URL'),
            env('FIND_LOCATION_API_PRODUCITON_URL'),
            $body
        ); 
        /*
        $response = HTTP::withHeaders([
            'content-type'=>'application/json',
            'authorization'=> Cookie::get('token_type')." ".Cookie::get('access_token_fedex'),
        ])->post(env('PRODUCTION_ENV') ?
            env('FIND_LOCATION_API_PRODUCITON_URL'): env('FIND_LOCATION_API_TEST_URL'), [
            'location' => $body,
        ]);
        */
        return response()->json([
            'validateAddressJson' => $response->json(),
            'statusCode' => $response->status(),
            'cookie' => $body,
        ]);
    }

    public function makeFedexJsonPostRequest($urlTest, $urlProduction, $jsonArray) {
        return $response = HTTP::withHeaders([
            'content-type'=>'application/json',
            'authorization'=> Cookie::get('token_type')." ".Cookie::get('access_token_fedex'),
        ])->post(env('PRODUCTION_ENV') ? $urlProduction: $urlTest, $jsonArray);
    }
    
    public function makeFedexJsonPutRequest($urlTest, $urlProduction, $jsonArray) {
        return $response = HTTP::withHeaders([
            'content-type'=>'application/json',
            'authorization'=> Cookie::get('token_type')." ".Cookie::get('access_token_fedex'),
        ])->put(env('PRODUCTION_ENV') ? $urlProduction: $urlTest, $jsonArray);
    }

    public function globalTradeRequest(Request $request){
        $requestJson = json_decode($request->get('global_trade'));
        $body = [
            "originAddress" => [
                "countryCode"=>$requestJson->{'countryCodeOrigin'},
                //"postalCode"=>"75063",
                //"stateOrProvinceCode"=>"TX"
            ],
            "destinationAddress" => [
                "countryCode"=>$requestJson->{'countryCodeDestination'},
                //"postalCode"=>"75063",
                //"stateOrProvinceCode"=>"TX"
            ],
            "carrierCode" => $requestJson->{'carrierCode'},
            /*"totalWeight" => [
                "units"=>"KG",
                "value"=>68
            ],*/
            "customsClearanceDetail" => [
                "customsValue" => [
                    "amount"=>"",
                    "currency"=>""
                ],
                "commodities" => array(
                    [
                        "harmonizedCode"=>$requestJson->{'harmonizedCode'},
                    ]
                ),
            ],
        ];
        $response = $this->makeFedexJsonPostRequest(
            env('GLOBAL_TRADE_API_TEST_URL'),
            env('GLOBAL_TRADE_API_PRODUCITON_URL'),
            $body
        ); 
        return response()->json([
            'validateAddressJson' => $response->json(),
            'statusCode' => $response->status(),
            'cookie' => $body,
        ]);
    }

    public function validationFedexRequest(Request $request){
        $addressJson = json_decode($request->get('address_to_validate'));
        $body = array(
                [
                    "address"=>[
                        "streetLines"=>array(
                            $addressJson->{'street_lines'},
                        ),
                        "countryCode"=>$addressJson->{'country_code'},
                    ],
                ]
            );
        $response = HTTP::withHeaders([
            'content-type'=>'application/json',
            'authorization'=> Cookie::get('token_type')." ".Cookie::get('access_token_fedex'),
        ])->post(env('PRODUCTION_ENV') ?
            env('ADDRES_VALIDATION_PRODUCTION_URL'): env('ADDRES_VALIDATION_TEST_URL'), [
            'addressesToValidate' => $body,
        ]);
        return response()->json([
            'validateAddressJson' => $response->json(),
            'statusCode' => $response->status(),
            'cookie' => $body,
        ]);
    }

    public function addresValidation(Request $request){
        $jayParsedAry = [
            "Arabic" => "ar_AE", 
            "Bulgarian" => "bg_BG", 
            "Chinese" => "zh_CN", 
            "Czech" => "cs_CZ", 
            "Danish" => "da_DK", 
            "Dutch" => "nl_NL", 
            "English" => "en_CA", 
            "English (United States)" => "en_US", 
            "Estonian" => "et_EE", 
            "Finnish" => "fi_FI", 
            "French" => "fr_CA", 
            "German" => "de_DE", 
            "Greek" => "el_GR", 
            "Hungarian" => "hu_HU", 
            "Italian" => "it_IT", 
            "Japanese" => "ja_JP", 
            "Korean" => "ko_KR", 
            "Latvian" => "lv_LV", 
            "Lithuanian" => "lt_LT", 
            "Norwegian" => "no_NO", 
            "Polish" => "pl_PL", 
            "Portuguese" => "pt_BR", 
            "Romanian" => "ro_RO", 
            "Russian" => "ru_RU", 
            "Slovak" => "sk_SK", 
            "Slovenian" => "sl_SI", 
            "Spanish" => "es_AR", 
            "Swedish" => "sv_SE", 
            "Thai" => "th_TH", 
            "Turkish" => "tr_TR", 
            "Ukrainian" => "uk_UA", 
            "Vietnamese" => "ar_AE" 
         ]; 
          
        $countryCode = $this->getCountryCode(); 
        return view('fedex.addresValidation', compact('jayParsedAry'), compact('countryCode'));
    }

    private function getCountryCode()
    {
        return [
            "Afghanistan" => "AF", 
            "Albania" => "AL", 
            "Algeria" => "DZ", 
            "American_Samoa" => "AS", 
            "Andorra" => "AD", 
            "Angola" => "AO", 
            "Anguilla" => "AI", 
            "Antarctica" => "AQ", 
            "Antigua,_Barbuda" => "AG", 
            "Argentina" => "AR", 
            "Armenia" => "AM", 
            "Aruba" => "AW", 
            "Australia" => "AU", 
            "Austria" => "AT", 
            "Azerbaijan" => "AZ", 
            "Bahamas" => "BS", 
            "Bahrain" => "BH", 
            "Bangladesh" => "BD", 
            "Barbados" => "BB", 
            "Belarus" => "BY", 
            "Belgium" => "BE", 
            "Belize" => "BZ", 
            "Benin" => "BJ", 
            "Bermuda" => "BM", 
            "Bhutan" => "BT", 
            "Bolivia" => "BO", 
            "Bonaire,_Caribbean_Netherlands,_Saba,_St._Eustatius" => "BQ", 
            "Bosnia-Herzegovina" => "BA", 
            "Botswana" => "BW", 
            "Bouvet_Island" => "BV", 
            "Brazil" => "BR", 
            "British_Indian_Ocean_Territory" => "IO", 
            "Brunei" => "BN", 
            "Bulgaria" => "BG", 
            "Burkina_Faso" => "BF", 
            "Burundi" => "BI", 
            "Cambodia" => "KH", 
            "Cameroon" => "CM", 
            "Canada" => "CA", 
            "Cape_Verde" => "CV", 
            "Central_African_Republic" => "CF", 
            "Chad" => "TD", 
            "Chile" => "CL", 
            "China" => "CN", 
            "Christmas_Island" => "CX", 
            "Cocos_(Keeling)_Islands" => "CC", 
            "Colombia" => "CO", 
            "Comoros" => "KM", 
            "Congo" => "CG", 
            "Congo,_Democratic_Republic_Of" => "CD", 
            "Cook_Islands" => "CK", 
            "Costa_Rica" => "CR", 
            "Croatia" => "HR", 
            "Cuba" => "CU", 
            "Curacao" => "CW", 
            "Cyprus" => "CY", 
            "Czech_Republic" => "CZ", 
            "Denmark" => "DK", 
            "Djibouti" => "DJ", 
            "Dominica" => "DM", 
            "Dominican_Republic" => "DO", 
            "East_Timor" => "TL", 
            "Ecuador" => "EC", 
            "Egypt" => "EG", 
            "El_Salvador" => "SV", 
            "England,_Great_Britain,_Northern_Ireland,_Scotland,_United_Kingdom,_Wales,_Channel_Islands" => "GB", 
            "Equatorial_Guinea" => "GQ", 
            "Eritrea" => "ER", 
            "Estonia" => "EE", 
            "Ethiopia" => "ET", 
            "Faeroe_Islands" => "FO", 
            "Falkland_Islands" => "FK", 
            "Fiji" => "FJ", 
            "Finland" => "FI", 
            "France" => "FR", 
            "French_Guiana" => "GF", 
            "French_Southern_Territories" => "TF", 
            "Gabon" => "GA", 
            "Gambia" => "GM", 
            "Georgia" => "GE", 
            "Germany" => "DE", 
            "Ghana" => "GH", 
            "Gibraltar" => "GI", 
            "Grand_Cayman,_Cayman_Islands" => "KY", 
            "Great_Thatch_Island,_Great_Tobago_Islands,_Jost_Van_Dyke_Islands,_Norman_Island,_Tortola_Island,_British_Virgin_Islands" => "VG", 
            "Greece" => "GR", 
            "Greenland" => "GL", 
            "Grenada" => "GD", 
            "Guadeloupe" => "GP", 
            "Guam" => "GU", 
            "Guatemala" => "GT", 
            "Guinea" => "GN", 
            "Guinea_Bissau" => "GW", 
            "Guyana" => "GY", 
            "Haiti" => "HT", 
            "Heard_and_McDonald_Islands" => "HM", 
            "Honduras" => "HN", 
            "Hong_Kong" => "HK", 
            "Hungary" => "HU", 
            "Iceland" => "IS", 
            "India" => "IN", 
            "Indonesia" => "ID", 
            "Iran" => "IR", 
            "Iraq" => "IQ", 
            "Ireland" => "IE", 
            "Israel" => "IL", 
            "Italy,_Vatican_City,_San_Marino" => "IT", 
            "Ivory_Coast" => "CI", 
            "Jamaica" => "JM", 
            "Japan" => "JP", 
            "Jordan" => "JO", 
            "Kazakhstan" => "KZ", 
            "Kenya" => "KE", 
            "Kiribati" => "KI", 
            "Kuwait" => "KW", 
            "Kyrgyzstan" => "KG", 
            "Laos" => "LA", 
            "Latvia" => "LV", 
            "Lebanon" => "LB", 
            "Lesotho" => "LS", 
            "Liberia" => "LR", 
            "Libya" => "LY", 
            "Liechtenstein" => "LI", 
            "Lithuania" => "LT", 
            "Luxembourg" => "LU", 
            "Macau" => "MO", 
            "Macedonia" => "MK", 
            "Madagascar" => "MG", 
            "Malawi" => "MW", 
            "Malaysia" => "MY", 
            "Maldives" => "MV", 
            "Mali" => "ML", 
            "Malta" => "MT", 
            "Marshall_Islands" => "MH", 
            "Martinique" => "MQ", 
            "Mauritania" => "MR", 
            "Mauritius" => "MU", 
            "Mayotte" => "YT", 
            "Mexico" => "MX", 
            "Micronesia" => "FM", 
            "Moldova" => "MD", 
            "Monaco" => "MC", 
            "Mongolia" => "MN", 
            "Montenegro" => "ME", 
            "Montserrat" => "MS", 
            "Morocco" => "MA", 
            "Mozambique" => "MZ", 
            "Myanmar_/_Burma" => "MM", 
            "Namibia" => "NA", 
            "Nauru" => "NR", 
            "Nepal" => "NP", 
            "Netherlands,_Holland" => "NL", 
            "New_Caledonia" => "NC", 
            "New_Zealand" => "NZ", 
            "Nicaragua" => "NI", 
            "Niger" => "NE", 
            "Nigeria" => "NG", 
            "Niue" => "NU", 
            "Norfolk_Island" => "NF", 
            "North_Korea" => "KP", 
            "Northern_Mariana_Islands,_Rota,_Saipan,_Tinian" => "MP", 
            "Norway" => "NO", 
            "Oman" => "OM", 
            "Pakistan" => "PK", 
            "Palau" => "PW", 
            "Palestine" => "PS", 
            "Panama" => "PA", 
            "Papua_New_Guinea" => "PG", 
            "Paraguay" => "PY", 
            "Peru" => "PE", 
            "Philippines" => "PH", 
            "Pitcairn" => "PN", 
            "Poland" => "PL", 
            "Portugal" => "PT", 
            "Puerto_Rico" => "PR", 
            "Qatar" => "QA", 
            "Reunion" => "RE", 
            "Romania" => "RO", 
            "Russia" => "RU", 
            "Rwanda" => "RW", 
            "Samoa" => "WS", 
            "Sao_Tome_and_Principe" => "ST", 
            "Saudi_Arabia" => "SA", 
            "Senegal" => "SN", 
            "Serbia" => "RS", 
            "Seychelles" => "SC", 
            "Sierra_Leone" => "SL", 
            "Singapore" => "SG", 
            "Slovak_Republic" => "SK", 
            "Slovenia" => "SI", 
            "Solomon_Islands" => "SB", 
            "Somalia" => "SO", 
            "South_Africa" => "ZA", 
            "South_Georgia_and_South_Sandwich_Islands" => "GS", 
            "South_Korea" => "KR", 
            "Spain,_Canary_Islands" => "ES", 
            "Sri_Lanka" => "LK", 
            "St._Barthelemy" => "BL", 
            "St._Christopher,_St._Kitts_And_Nevis" => "KN", 
            "St._John,_St._Thomas,_U.S._Virgin_Islands,_St._Croix_Island" => "VI", 
            "St._Helena" => "SH", 
            "St._Lucia" => "LC", 
            "St._Maarten_(Dutch_Control)" => "SX", 
            "St._Martin_(French_Control)" => "MF", 
            "St._Pierre" => "PM", 
            "St._Vincent,_Union_Island" => "VC", 
            "Sudan" => "SD", 
            "Suriname" => "SR", 
            "Svalbard_and_Jan_Mayen_Island" => "SJ", 
            "Swaziland" => "SZ", 
            "Sweden" => "SE", 
            "Switzerland" => "CH", 
            "Syria" => "SY", 
            "Tahiti,_French_Polynesia" => "PF", 
            "Taiwan" => "TW", 
            "Tajikistan" => "TJ", 
            "Tanzania" => "TZ", 
            "Thailand" => "TH", 
            "Togo" => "TG", 
            "Tokelau" => "TK", 
            "Tonga" => "TO", 
            "Trinidad_and_Tobago" => "TT", 
            "Tunisia" => "TN", 
            "Turkey" => "TR", 
            "Turkmenistan" => "TM", 
            "Turks_and_Caicos_Islands" => "TC", 
            "Tuvalu" => "TV", 
            "U.S._Minor_Outlying_Islands" => "UM", 
            "Uganda" => "UG", 
            "Ukraine" => "UA", 
            "United_Arab_Emirates" => "AE", 
            "United_States" => "US", 
            "Uruguay" => "UY", 
            "Uzbekistan" => "UZ", 
            "Vanuatu" => "VU", 
            "Venezuela" => "VE", 
            "Vietnam" => "VN", 
            "Wallis_and_Futuna_Islands" => "WF", 
            "Western_Sahara" => "EH", 
            "Yemen" => "YE", 
            "Zambia" => "ZM", 
            "Zimbabwe" => "ZW" 
        ]; 
    }

}
