
<?php $__env->startSection('content'); ?>
    <section>
        <h3>Llamadas a la api de FEDEX  <?php echo e($response); ?></h3>
        <hr>
        <ul>
            <li>Obtener token de autorizacion</li>
            <li>API de validación de direcciones</li>
            <li>API de búsqueda de ubicaciones de Fedex</li>
            <li>API de comercio global</li>
            <li>API de cierre de fin de día terrestre</li>
            <li>API de envío abierto</li>
            <li>API de solicitud de recogida</li>
            <li>API de validación de código postal</li>
            <li>API de tarifas y tiempos de tránsito</li>
            <li>API de disponibilidad del servicio</li>
            <li>API de envío</li>
            <li>API de seguimiento</li>
            <li>API de carga de documentos comerciales</li>
        </ul>

    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\torch\resources\views/fedex/indexFedex.blade.php ENDPATH**/ ?>