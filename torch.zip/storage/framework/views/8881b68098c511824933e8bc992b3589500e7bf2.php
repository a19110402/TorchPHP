
<?php $__env->startSection('content'); ?>
    <section>
        <h3>Llamadas a la api de FEDEX</h3>
        <hr>
        <ul>
            <a href="<?php echo e(url('/fedex/auth')); ?>"><li>Obtener token de autorizacion</li></a>
            <a href="<?php echo e(url('/fedex/addresValidationForm')); ?>"><li>API de validación de direcciones</li></a>
            <a href="<?php echo e(url('/fedex/findLocationForm')); ?>"><li>API de búsqueda de ubicaciones de Fedex</li></a>
            <a href="<?php echo e(url('/fedex/globalTradeForm')); ?>"><li>API de comercio global</li></a>
            <a href="<?php echo e(url('/fedex/GroundDayCloseForm')); ?>"><li>API de cierre de fin de día terrestre</li></a>
            <li>API de envío abierto</li>
            <a href="<?php echo e(url('/fedex/')); ?>"><li>API de solicitud de recogida</li></a>
            <a href="<?php echo e(url('/fedex/')); ?>"><li>API de validación de código postal</li></a>
            <a href="<?php echo e(url('/fedex/')); ?>"><li>API de tarifas y tiempos de tránsito</li></a>
            <a href="<?php echo e(url('/fedex/')); ?>"><li>API de disponibilidad del servicio</li></a>
            <a href="<?php echo e(url('/fedex/')); ?>"><li>API de envío</li></a>
            <a href="<?php echo e(url('/fedex/')); ?>"><li>API de seguimiento</li></a>
            <a href="<?php echo e(url('/fedex/')); ?>"><li>API de carga de documentos comerciales</li></a>
        </ul>

    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\torch\resources\views/fedex/index.blade.php ENDPATH**/ ?>