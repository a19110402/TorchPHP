
<?php $__env->startSection('content'); ?>
    <form method='POST' action="javascript:void(0);" data-action="<?php echo e(url('/fedex')); ?>" id="get-validate-addres-fedex-form">
        <?php echo csrf_field(); ?>
        <h3>Address Validation API</h3>
        <fieldset>
            <legend>Use this endpoint to get address resolution details.</legend>
            <label for="x-customer-transaction-id">
                This element allows you to assign a unique identifier to your transaction. (customer-transaction)<br>
            </label>
            <input placeholder="customer-transaction" type="text" name="x-customer-transaction-id"><br><br>
            
            <label for="streetLines">
                Indicate the combination of number, street name. etc. (streetLines)<br>
            </label>
            <input placeholder="streetLines" type="text" name="streetLines" required><br><br>
            
            <label for="countryCode">
                Specify the ISO Alpha2 code of the country. (countryCode)<br>
                Example: US
            </label>
            
            <select name="countryCode" required>
            <?php $__currentLoopData = $countryCode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($country); ?>"><?php echo e($code); ?> (<?php echo e($country); ?>)</option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select><br><br>

            <label for="x-locale">Choose a Locale: (x-locale)</label>
            <select name="x-locale">
                <?php $__currentLoopData = $jayParsedAry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locate => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($val); ?>"><?php echo e($locate); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <br>
            <input type="submit" value="Submit">
        </fieldset>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/fedex/val-addres.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\torch\resources\views/fedex/addresValidation.blade.php ENDPATH**/ ?>