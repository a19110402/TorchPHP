<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;1,400;1,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(url('css/au.css')); ?>">
    <?php echo $__env->yieldContent('extraCSS'); ?><?php $__env->startSection('extraCSS'); ?>
    <title>Torch</title>
</head>
<body>
    <header>
        <div class="logo">
            <a href="/">
                <picture>
                    <img src="<?php echo e(asset('img/descarga.png')); ?>" alt="LogoEmpresa">
                </picture>
            </a>
        </div>
        <div class="navegacion-principal">
            <a href="#">Envíos</a>
            <a href="#">Rastreo</a>
            <a href="#">Logística</a>
            <a href="#">Promociones</a>
            <a href="#">Crear cuenta</a>
            <a href="#">Iniciar sesión</a>
        </div>
    </header>


    <?php echo $__env->yieldContent('content'); ?><?php $__env->startSection('content'); ?>

    <footer class="footer">
        <div>
            <img src="" alt="Logo de empresa">
        </div><!---->
        <div>
            <p>Recursos de apoyo</p>
            <a href=""></a>
        </div>
        <div>
            <p>Envíos</p>
            <a href=""></a>
        </div>
        <div>
            <p>Paqueterías</p>
            <a href=""></a>
        </div>
        <div>
            <p>Rastreo</p>
            <a href=""></a>
        </div>
        <div>
            <p>Cotizar</p>
            <a href=""></a>
        </div>
        <div>
            <p>Nosotros</p>
            <a href=""></a>
        </div>
        <div>
            <p>Contactanos</p>
            <a href=""></a>
        </div>
    </footer>
    <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
    <?php echo $__env->yieldContent('scripts'); ?><?php $__env->startSection('scripts'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\torch\resources\views/layouts/base.blade.php ENDPATH**/ ?>