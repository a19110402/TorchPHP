
<?php $__env->startSection('content'); ?>
    <form method='POST' action="javascript:void(0);" data-action="<?php echo e(url('/fedex')); ?>" id="get-key-auth-fedex-form">
        <?php echo csrf_field(); ?>
        <h3>API Authorization</h3>
        <fieldset>
            <legend>Fill in the customer information</legend>
            <label for="client_id">Specify the Client ID also known as Customer Key. </label>
            <input placeholder="Customer key" type="text" name="client_id"><br><br>
            <label for="child_secret">Specify the Client secret also known as Customer Secret.</label>
            <input placeholder="Customer secret" type="text" name="child_secret"><br><br>
            <input type="submit" value="Submit">
        </fieldset>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/fedex/auth.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\torch\resources\views/fedex/auth.blade.php ENDPATH**/ ?>