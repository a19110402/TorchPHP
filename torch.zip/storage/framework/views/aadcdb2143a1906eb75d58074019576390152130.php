
<?php $__env->startSection('content'); ?>
    <form method='POST' action="javascript:void(0);" data-action="<?php echo e(url('/fedex')); ?>" id="find-location-fedex-form">
        <?php echo csrf_field(); ?>
        <h3>FedEx Location Search API</h3>
        <fieldset>
            <legend>Fill in the customer information</legend>

            <label for="city">
                This is a placeholder for City Name.
                City or PostalCode is mandatory when search criteria is ADDRESS or PHONE_NUMBER
                Example: Beverly Hills<br>
            </label>
            <input placeholder="city" type="text" name="city" required><br><br>

            <label for="latitude">
                The geo coordinate value that specifies the north-south position of the address.<br>
            </label>
            <input placeholder="latitude" type="text" name="latitude" required><br><br>
            
            <label for="longitude">
                The geo coordinate value that specifies the East-West position of the address.<br>
            </label>
            <input placeholder="longitude" type="text" name="longitude" required><br><br>

            <label for="countryCode">
                Specify the ISO Alpha2 code of the country. (countryCode)<br>
                Example: US
            </label>
            <select name="countryCode" required>
            <?php $__currentLoopData = $countryCodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($country); ?>"><?php echo e($code); ?> (<?php echo e($country); ?>)</option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select><br><br>
            <input type="submit" value="Submit">
        </fieldset>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/fedex/find_location.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\torch\resources\views/fedex/findLocationForm.blade.php ENDPATH**/ ?>